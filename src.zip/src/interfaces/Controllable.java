package interfaces;

import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public interface Controllable {
    void turnOn();
    void turnOff();
    boolean isOn();
}