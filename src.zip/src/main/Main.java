package main;

import logic.Scenario;
import logic.SmartHomeManager;
import models.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        SmartHomeManager manager = new SmartHomeManager();
        Scanner scanner = new Scanner(System.in);

        boolean running = true;
        while(running) {
            System.out.println("\nУмный дом:");
            System.out.println("1. Добавить устройство");
            System.out.println("2. Вкл/выкл устройство");
            System.out.println("3. Сценарий - сброс фантомного напряжения");
            System.out.println("4. Свой сценарий");
            System.out.println("5. Запустить все сценарии");
            System.out.println("6. Своя аналитика");
            System.out.println("7. Выйти из программы");
            System.out.print("Выберите пункт: ");

            String choice = scanner.nextLine();

            switch(choice) {
                case "1": addDeviceID(scanner, manager); break;
                case "2": onoffDevice(scanner, manager); break;
                case "3": addScenario1(manager); break;
                case "4": addScenario2(manager); break;
                case "5": manager.executeAllScenarios(); break;
                case "6": addAnalytics(manager); break;
                case "7": System.out.println("Выход из программы.");
                    running = false; break;
                default: System.out.println("Ошибка. Попробуйте снова.");
            }
        }
        scanner.close();
    }

    private static void addDeviceID(Scanner scanner, SmartHomeManager manager) {
        System.out.print("Введите тип (1-Лампа, 2-Термостат, 3-Розетка): ");
        String type = scanner.nextLine();
        System.out.print("Введите ID: ");
        String id = scanner.nextLine();
        System.out.print("Введите имя: ");
        String name = scanner.nextLine();
        System.out.print("Введите комнату: ");
        String room = scanner.nextLine();
        System.out.print("Введите текущее потребление (Вт): ");
        double power;
        try {
            power = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            power = 0.0;
        }

        Device device = null;
        switch (type) {
            case "1":
                System.out.print("Введите яркость (0-100): ");
                int brightness = Integer.parseInt(scanner.nextLine());
                System.out.print("Введите цвет: ");
                String color = scanner.nextLine();
                device = new SmartLight(id, name, power, brightness, color);
                break;
            case "2":
                System.out.print("Введите целевую температуру: ");
                double temp = Double.parseDouble(scanner.nextLine());
                device = new SmartThermostat(id, name, power, temp);
                break;
            case "3":
                System.out.print("Введите нагрузку (Вт): ");
                double load = Double.parseDouble(scanner.nextLine());
                device = new SmartSocket(id, name, power, load);
                break;
            default:
                System.out.println("Неверный тип устройства.");
                return;
        }

        manager.addDevice(room, device);
        System.out.println("Устройство добавлено.");
    }

    private static void onoffDevice(Scanner scanner, SmartHomeManager manager) {
        System.out.print("Введите ID устройства: ");
        String id = scanner.nextLine();
        Device d = manager.getDeviceById(id);
        if (d == null) {
            System.out.println("Устройство не найдено.");
            return;
        }
        System.out.println("Текущий статус: " + (d.isOn() ? "Включено" : "Выключено"));
        System.out.print("Введите новое состояние (on/off): ");
        String state = scanner.nextLine();
        if (state.equalsIgnoreCase("on")) {
            d.turnOn();
        } else if (state.equalsIgnoreCase("off")) {
            d.turnOff();
        } else {
            System.out.println("Неверная команда.");
        }
    }

    private static void addScenario1(SmartHomeManager manager) {
        Scenario<Device> phantom = new Scenario<>(
                "Сброс фантомного потребления",
                device -> !device.isOn() && device.getPowerConsumption() > 0,
                device -> device.setPowerConsumption(0.0)
        );
        manager.addScenario(phantom);
        System.out.println("Сценарий 'Сброс фантомного потребления' добавлен.");
    }

    private static void addScenario2(SmartHomeManager manager) {
        Scenario<SmartSocket> energySave = new Scenario<>(
                "Энергосбережение (Вариант 1)",
                socket -> socket.isOn() && socket.getCurrentLoad() > 2000,
                socket -> {
                    socket.turnOff();
                    System.out.println("Сценарий: Розетка " + socket.getName() + " выключена.");
                }
        );
        manager.addScenario(energySave);
        System.out.println("Сценарий 'Энергосбережение (Вариант 1)' добавлен.");
    }

    private static void addAnalytics(SmartHomeManager manager) {
        System.out.println("ТОП-3 самых энергозатратных устройств (Вариант 1):");
        manager.getAnalyticsStream()
                .sorted(Comparator.comparingDouble(Device::getPowerConsumption).reversed())
                .limit(3)
                .forEach(device -> System.out.println(device.getDetails()));
    }
}